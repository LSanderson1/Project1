#include "caterpie.h"
#include <iostream>

using namespace std;

Caterpie::Caterpie() : Pokemon()
{
    cout << "Caterpie Constructor" << endl;
    type = "Bug";
    weight = 2.9f;
}

Caterpie::~Caterpie()
{
    cout << "Caterpie Destructor" << endl;
}
void Caterpie::printData() 
{
    cout << "Caterpie:" << endl;
    cout << "type : " << type << endl;
    cout << "weight: " << weight << endl;
}