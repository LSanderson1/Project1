#include "wartortle.h"
#include <iostream>


using namespace std;

Wartortle::Wartortle() : Pokemon()
{
    cout << "Wartortle Constructor" << endl;
    type = "Water";
    weight = 22.5f;
}

Wartortle::~Wartortle()
{
    cout << "Wartortle Destructor" << endl;
}
void Wartortle::printData() 
{
    cout << "Wartortle:" << endl;
    cout << "type : " << type << endl;
    cout << "weight: " << weight << endl;
}