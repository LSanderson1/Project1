#ifndef POKEMON_H
#define POKEMON_H

#include <string>

using namespace std;

class Pokemon
{
    public:
    Pokemon();

    virtual ~Pokemon();

    virtual void printData() = 0;


    protected:
    string type; // e.g., electric, poison, etc
    float weight;
};

#endif