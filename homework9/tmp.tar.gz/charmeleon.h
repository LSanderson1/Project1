#ifndef CHARMELEON_H
#define CHARMELEON_H

#include "pokemon.h"

class Charmeleon : public Pokemon
{
    public:
    Charmeleon();

    virtual ~Charmeleon();

    void printData();
};

#endif