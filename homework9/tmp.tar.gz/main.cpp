#include <string>
#include <iostream>
#include <vector>
#include <map>

#include "pokemon.h"
#include "wartortle.h"
#include "charmeleon.h"
#include "caterpie.h"

using namespace std;


void checkPokedex(Pokemon *pokemon)
{
    pokemon->printData();
}

int main()
{
    std::vector < std::string > names;
    cout << "inserting names " << endl;
    names.push_back("zappy");
    names.push_back("zack");
    names.push_back("jack");
    cout << endl;

    std::map < std::string, Pokemon * > pokemons;
    
    cout << "creating pokemon zappy the wartortle" << endl;
    Pokemon *zappy = new Wartortle();
    cout << endl;
    cout << "creating pokemon zack the charmeleon" << endl;
    Pokemon *zack = new Charmeleon();
    cout << endl;
    cout << "creating pokemon jack the carterpie" << endl;
    Pokemon *jack = new Caterpie();
    cout << endl;

    cout << "inserting pokemons " << endl; 
    pokemons.insert(std::make_pair(names[0], zappy));
    pokemons.insert(std::make_pair(names[1], zack));
    pokemons.insert(std::make_pair(names[2], jack));
    cout << endl;

    cout << "iterating over the names " << endl;
    for(vector<string>::iterator it = names.begin(); it != names.end(); it++)
    {
        cout << "using key: '" << *it << "'" << endl;
        Pokemon *pokemon = pokemons.find(*it)->second;

        cout << "calling the 'checkPokedex()' function" << endl;
        checkPokedex(pokemon);
        cout << endl;

        cout << "deleting pokemon '" << *it << "'" << endl;
        delete pokemon;
        cout << endl;
    }
    cout << endl;

    pokemons.clear();


    return 0;
}