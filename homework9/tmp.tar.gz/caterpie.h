#ifndef CATERPIE_H
#define CATERPIE_H

#include "pokemon.h"

class Caterpie : public Pokemon
{
    public:
    Caterpie();

    virtual ~Caterpie();

    void printData();
};

#endif