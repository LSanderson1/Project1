#include "charmeleon.h"
#include <iostream>

using namespace std;

Charmeleon::Charmeleon() : Pokemon()
{
    cout << "Charmeleon Constructor" << endl;
    type = "Fire";
    weight = 5.f;
}

Charmeleon::~Charmeleon()
{
    cout << "Charmeleon Destructor" << endl;
}
void Charmeleon::printData() 
{
    cout << "Charmeleon:" << endl;
    cout << "type : " << type << endl;
    cout << "weight: " << weight << endl;
}