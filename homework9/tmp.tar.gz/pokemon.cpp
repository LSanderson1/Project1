#include "pokemon.h"
#include <iostream>

using namespace std;

Pokemon::Pokemon()
{
    cout << "Pokemon Constructor" << endl;
}

Pokemon::~Pokemon()
{
    cout << "Pokemon Destructor" << endl;
}