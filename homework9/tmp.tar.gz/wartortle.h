#ifndef WARTORTLE_H
#define WARTORTLE_H

#include "pokemon.h"

class Wartortle : public Pokemon
{
    public:
    Wartortle();

    virtual ~Wartortle();

    void printData();
};

#endif